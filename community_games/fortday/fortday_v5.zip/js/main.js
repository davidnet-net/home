'use strict';
// ═══════════════════════════════════════════════════════════
//  INPUT + GAME LOOP + BOOT
// ═══════════════════════════════════════════════════════════
//  1-5 / scroll: items · X: pickaxe · Q wall · F floor · C ramp · G edit
//  E pick up · R reload · right mouse: aim · T chat · M main menu · Space: jump (or leave the bus)
const BUILD_KEYS={KeyQ:'wall',KeyF:'floor',KeyC:'ramp',KeyG:'edit'};
const SLOT_KEYS={Digit1:0,Digit2:1,Digit3:2,Digit4:3,Digit5:4};
let lastWheel=0, lastAutoBuild=0;

renderer.domElement.addEventListener('click',()=>{ if(gameStarted&&!gameOver) renderer.domElement.requestPointerLock(); });
$('lockp').addEventListener('click',()=>{ if(gameStarted&&!gameOver) renderer.domElement.requestPointerLock(); });
document.addEventListener('pointerlockchange',()=>{
  isLocked=document.pointerLockElement===renderer.domElement;
  $('lockp').style.display=(!isLocked&&gameStarted&&!gameOver&&!(isDead&&!isPit())&&!chatOpen)?'flex':'none';
  if(!isLocked){ mouseHeld=false; aiming=false; }
});
document.addEventListener('mousemove',e=>{
  if(!isLocked||isDead) return;
  const s=.0022*(aiming?(camera.fov/75):1);
  camYaw.y-=e.movementX*s; camYaw.x-=e.movementY*s;
  camYaw.x=clamp(camYaw.x,-Math.PI/2+.05,Math.PI/2-.05);
});
document.addEventListener('wheel',e=>{
  if(!gameStarted) return;
  e.preventDefault();
  if(isDead||inBus||chatOpen) return;
  const dir=Math.sign(e.deltaY); if(!dir) return;
  const now=performance.now(); if(now-lastWheel<90) return; lastWheel=now;
  cycleWeapon(dir);
},{passive:false});

document.addEventListener('keydown',e=>{
  if(chatOpen) return;                              // typing in the chat box
  keys[e.code]=true;
  if(!gameStarted) return;
  if(e.code==='Tab'||e.code==='Space') e.preventDefault();
  if(e.repeat) return;
  if(e.code==='KeyT'){ e.preventDefault(); openChat(); return; }
  if(e.code==='KeyM'){ leaveToMenu(false); return; }
  if(e.code==='Escape'){ document.exitPointerLock(); return; }
  if(inBus){ if(e.code==='Space') jumpFromBus(false); return; }
  if(isDead) return;
  if(e.code in SLOT_KEYS){ const i=SLOT_KEYS[e.code]; if(inventory[i]) switchSlot(i); return; }
  if(e.code==='KeyX'){ switchSlot(-1); return; }
  if(e.code in BUILD_KEYS){ const m=BUILD_KEYS[e.code]; if(buildMode===m) backToGun(); else setMode(m); return; }
  if(e.code==='KeyR'&&buildMode==='gun'&&!isReloading) startReload();
  if(e.code==='KeyE') tryPickup();
});
document.addEventListener('keyup',e=>{ keys[e.code]=false; });
document.addEventListener('mousedown',e=>{
  SFX.unlock();
  if(!isLocked||!gameStarted||isDead||inBus) return;
  if(e.button===0){
    mouseHeld=true;
    if(buildMode==='gun') doPrimary();
    else if(buildMode==='edit') doEdit();
    else { lastAutoBuild=performance.now(); updateGhost(); doBuild(); }
  }
  if(e.button===2){
    if(buildMode!=='gun') backToGun();
    else if(isGunLike(curType())) aiming=true;
  }
});
document.addEventListener('mouseup',e=>{ if(e.button===0) mouseHeld=false; if(e.button===2) aiming=false; });
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('pointerdown',()=>SFX.unlock(),{once:true});

// Holding the mouse: automatic weapons keep firing, pickaxe keeps swinging, building keeps placing
function holdActions(now){
  if(!mouseHeld||!isLocked||isDead||inBus) return;
  if(buildMode==='gun'){ const t=curType(); if(t&&ITEMS[t].auto) doPrimary(); }
  else if(buildMode!=='edit'&&now-lastAutoBuild>70){ lastAutoBuild=now; updateGhost(); doBuild(); }
}

// ═══════════════════════════════════════════════════════════
//  LOOP
// ═══════════════════════════════════════════════════════════
let prevT=0, mmTimer=0;
function animate(ts){
  requestAnimationFrame(animate);
  const dt=Math.min((ts-prevT)/1000,.05); prevT=ts;
  if(!gameStarted){
    const a=ts*.0003;
    camera.position.set(Math.cos(a)*18,7,Math.sin(a)*18); camera.lookAt(0,2,0);
    renderer.autoClear=true; renderer.render(scene,camera);
    return;
  }
  const now=performance.now();
  updateBus(now);
  updatePlayer(dt);
  holdActions(now);
  updateGhost();
  updateBullets(dt); updateProjectiles(dt); updateEffects(dt);
  updatePickups(dt,ts); updateFalling(dt);
  updateUse(now); updateBar(now);
  if(isBR()) updateStorm(dt,now);

  // keep the sun (and its shadow area) centred on the player
  const cx=camera.position.x, cz=camera.position.z;
  sun.position.set(cx+SUN_OFF.x,SUN_OFF.y,cz+SUN_OFF.z); sun.target.position.set(cx,0,cz); sun.target.updateMatrixWorld();
  sunDisc.position.copy(camera.position).addScaledVector(SUN_DIR,185);

  mmTimer+=dt; if(mmTimer>.06){ mmTimer=0; renderMinimap(); }

  renderer.autoClear=true; renderer.render(scene,camera);
  renderer.autoClear=false; renderer.clearDepth();
  wCamera.aspect=camera.aspect; wCamera.updateProjectionMatrix();
  renderer.render(wScene,wCamera);
  renderer.autoClear=true;
}
window.addEventListener('resize',()=>{
  camera.aspect=wCamera.aspect=innerWidth/innerHeight;
  camera.updateProjectionMatrix(); wCamera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});

// ═══════════════════════════════════════════════════════════
//  BOOT
// ═══════════════════════════════════════════════════════════
buildHotbar(); updateHotbarUI(); updateHpUI();
try{
  RT().onPresence(ev=>{
    if(!ev) return;
    if(ev.room===PIT_ROOM&&isPit()) onPitPresence(ev);
    else if(ev.room===BR_LOBBY) onLobbyPresence(ev);
    else onMatchPresence(ev);
  });
}catch(e){}
(async()=>{ await loadStats(); showLB('kills'); autoRequeue(); })();
loadSettings();
pollMenuCounts(); menuPoll=setInterval(pollMenuCounts,3000);
animate(0);

// functions used from onclick="" attributes
Object.assign(window,{joinQueue,cancelQueue,joinPit,joinBR,leaveToMenu,showLB,toggleSound,toggleAchPanel,setMode,switchSlot});
