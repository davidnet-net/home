'use strict';
// ═══════════════════════════════════════════════════════════
//  MAPS: every mode has its own arena look (sky, ground, props, ruins, lava)
// ═══════════════════════════════════════════════════════════
const MAPS={
  '1v1':  {name:'Oude Ruïnes',     ground:0x7d8b56, sky:0x9cc6dc, fog:[90,210],  rock:0x8d8a7c, line:0x5d6b3a, props:[['tree',8],['rock',14]], ruins:12, ruinColor:0xa8a294},
  '2v2':  {name:'Dennenbos',       ground:0x4c7a36, sky:0x7fb2d0, fog:[70,190],  rock:0x6f7a68, line:0x3e6a2a, props:[['pine',40],['rock',8]]},
  '1v1v1':{name:'Zonnige Woestijn',ground:0xd9bb7c, sky:0xf1c690, fog:[100,230], rock:0xb58a5a, line:0xc2a064, props:[['cactus',24],['rock',14]], ruins:7, ruinColor:0xcfae78},
  ffa4:   {name:'Sneeuwvlakte',    ground:0xe6edf2, sky:0xbcd0e2, fog:[55,170],  rock:0x9aa5b1, line:0xc9d6e0, props:[['snowpine',32],['rock',10]]},
  pit:    {name:'De Krater',       ground:0x3b3434, sky:0x7a4a3a, fog:[80,200],  rock:0x2a2626, line:0x5a2a20, props:[['lavarock',24],['deadtree',9]], lava:true},
  br:     {name:'Fort Eiland',     ground:0x649a45, sky:SKY,      fog:[150,380]},
};
function hashStr(s){ let h=2166136261; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; }
let lavaRing=null;

function applyMapTheme(mode){
  const m=MAPS[mode]||MAPS['1v1'];
  scene.background.setHex(m.sky); scene.fog.color.setHex(m.sky);
  scene.fog.near=m.fog[0]; scene.fog.far=m.fog[1];
  ground.material.color.setHex(m.ground);
  if(m.rock!=null) arenaDecor.traverse(c=>{
    if(!c.isMesh) return;
    if(c.geometry.type==='DodecahedronGeometry') c.material.color.setHex(m.rock);
    else if(c.geometry.type==='PlaneGeometry') c.material.color.setHex(m.line);
  });
  if(m.lava&&!lavaRing){
    lavaRing=new THREE.Mesh(new THREE.RingGeometry(62,140,64),new THREE.MeshBasicMaterial({color:0xff5a1f,fog:false}));
    lavaRing.rotation.x=-Math.PI/2; lavaRing.position.y=.6; scene.add(lavaRing);
  }
  return m;
}
// Places props/ruins for an arena; identical on every client (seeded by the mode name)
function genArenaMap(mode){
  const m=MAPS[mode]; if(!m||mode==='br') return;
  const R=rng(hashStr('fortday-map-'+mode));
  const keepClear=[...ARENA_LOOT.map(l=>[l.x,l.z,3.2]),...SPAWN_POS.map(p=>[p[0],p[2],5]),[0,0,5]];
  const clear=(x,z,r)=>keepClear.every(([cx,cz,cr])=>Math.hypot(x-cx,z-cz)>cr+r);
  let pid=0;
  (m.props||[]).forEach(([kind,count])=>{
    for(let i=0,tries=0;i<count&&tries<count*12;tries++){
      const a=R()*Math.PI*2, r=8+R()*44, x=Math.cos(a)*r, z=Math.sin(a)*r, s=.75+R()*.55;
      if(!clear(x,z,2.5)) continue;
      addProp('a'+(pid++),kind,x,z,s,R); keepClear.push([x,z,2]); i++;
    }
  });
  // Ruins: small broken wall pieces made of normal (map) build pieces
  let n=0;
  for(let i=0,tries=0;i<(m.ruins||0)&&tries<(m.ruins||0)*20;tries++){
    const gx=Math.round((R()*2-1)*12), gz=Math.round((R()*2-1)*12);
    if(!clear(gx*GRID,gz*GRID,2)) continue;
    i++;
    const rot=R()<.5?0:1, len=1+Math.floor(R()*3);
    for(let k=0;k<len;k++){
      const wx=rot===0?gx+k:gx-.5, wz=rot===0?gz-.5:gz+k;
      placeBuild('wall',wx,0,wz,rot,MAP_TEAM,'r'+(n++),{color:m.ruinColor||0xa8a294,hp:300,mask:R()<.4?0x1FF&~(1<<7)&~(1<<8)&~(1<<6):0x1FF});
      if(R()<.3) placeBuild('wall',wx,1,wz,rot,MAP_TEAM,'r'+(n++),{color:m.ruinColor||0xa8a294,hp:300,mask:0x07});
    }
    keepClear.push([gx*GRID,gz*GRID,6]);
  }
}
